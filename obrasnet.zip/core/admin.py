from django.contrib import admin
from . models import Expert

# Register your models here.

admin.site.register(Expert)