EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'jojoskeogh@gmail.com'
EMAIL_HOST_PASSWORD = 'Healer@1994'
EMAIL_PORT = 587